<?php
/**
 * Plugin Name: WPM Test security
 */
register_activation_hook(__FILE__, function () { update_option("wpm_test_security_activated", "yes"); });
