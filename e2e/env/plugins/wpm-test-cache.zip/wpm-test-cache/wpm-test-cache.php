<?php
/**
 * Plugin Name: WPM Test cache
 */
register_activation_hook(__FILE__, function () { update_option("wpm_test_cache_activated", "yes"); });
