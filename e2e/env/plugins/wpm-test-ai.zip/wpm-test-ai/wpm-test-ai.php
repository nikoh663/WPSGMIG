<?php
/**
 * Plugin Name: WPM Test ai
 */
